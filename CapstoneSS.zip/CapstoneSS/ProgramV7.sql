--drop database StrongStart
USE [master]
GO
/****** Object:  Database [MvcMusicStore]    Script Date: 2019-05-22 4:06:42 PM ******/
CREATE DATABASE [StrongStart]
GO
ALTER DATABASE [StrongStart] SET COMPATIBILITY_LEVEL = 100
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [StrongStart].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [StrongStart] SET ANSI_NULL_DEFAULT OFF 
GO				
ALTER DATABASE [StrongStart] SET ANSI_NULLS OFF 
GO				
ALTER DATABASE [StrongStart] SET ANSI_PADDING OFF 
GO				
ALTER DATABASE [StrongStart] SET ANSI_WARNINGS OFF 
GO				
ALTER DATABASE [StrongStart] SET ARITHABORT OFF 
GO				
ALTER DATABASE [StrongStart] SET AUTO_CLOSE ON 
GO				
ALTER DATABASE [StrongStart] SET AUTO_SHRINK OFF 
GO				
ALTER DATABASE [StrongStart] SET AUTO_UPDATE_STATISTICS ON 
GO				
ALTER DATABASE [StrongStart] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO				
ALTER DATABASE [StrongStart] SET CURSOR_DEFAULT  GLOBAL 
GO				
ALTER DATABASE [StrongStart] SET CONCAT_NULL_YIELDS_NULL OFF 
GO				
ALTER DATABASE [StrongStart] SET NUMERIC_ROUNDABORT OFF 
GO				
ALTER DATABASE [StrongStart] SET QUOTED_IDENTIFIER OFF 
GO				
ALTER DATABASE [StrongStart] SET RECURSIVE_TRIGGERS OFF 
GO				
ALTER DATABASE [StrongStart] SET  DISABLE_BROKER 
GO				
ALTER DATABASE [StrongStart] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO				
ALTER DATABASE [StrongStart] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO				
ALTER DATABASE [StrongStart] SET TRUSTWORTHY OFF 
GO				
ALTER DATABASE [StrongStart] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO				
ALTER DATABASE [StrongStart] SET PARAMETERIZATION SIMPLE 
GO				
ALTER DATABASE [StrongStart] SET READ_COMMITTED_SNAPSHOT OFF 
GO				
ALTER DATABASE [StrongStart] SET HONOR_BROKER_PRIORITY OFF 
GO				
ALTER DATABASE [StrongStart] SET RECOVERY SIMPLE 
GO				
ALTER DATABASE [StrongStart] SET  MULTI_USER 
GO				
ALTER DATABASE [StrongStart] SET PAGE_VERIFY CHECKSUM  
GO		
ALTER DATABASE [StrongStart] SET DB_CHAINING OFF 
GO		
ALTER DATABASE [StrongStart] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO		
ALTER DATABASE [StrongStart] SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO			
ALTER DATABASE [StrongStart] SET DELAYED_DURABILITY = DISABLED 
GO				
ALTER DATABASE [StrongStart] SET QUERY_STORE = OFF
GO
USE [StrongStart]
GO
/****** Object:  Table [dbo].[album]    Script Date: 2019-05-22 4:06:42 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [startDate] (
  [startDateID] [int] IDENTITY(1,1) NOT NULL,
  [name] [varchar](255) NOT NULL,
  CONSTRAINT [PK_startDate] PRIMARY KEY CLUSTERED 
(
	[startDateId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO


CREATE TABLE [dbo].[sessionFrequency] (
  [sessionFrequencyID] [int] IDENTITY(1,1) NOT NULL,
  [name] [varchar](255) NOT NULL,
  CONSTRAINT [PK_sessionFrequency] PRIMARY KEY CLUSTERED 
(
	[sessionFrequencyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[programLength] (
  [programLengthID] [int] IDENTITY(1,1) NOT NULL,
  [name] [varchar](255) NOT NULL,
  CONSTRAINT [PK_programLength] PRIMARY KEY CLUSTERED 
(
	[programLengthId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO


CREATE TABLE [StartTime] (
  [startTimeID] [int] IDENTITY(1,1) NOT NULL,
  [name] [varchar](255) NOT NULL,
  CONSTRAINT [PK_startTime] PRIMARY KEY CLUSTERED 
(
	[startTimeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [SessionDuration] (
  [sessionDurationID] [int] IDENTITY(1,1) NOT NULL,
  [name] [varchar](255) NOT NULL,
  CONSTRAINT [PK_sessionDuration] PRIMARY KEY CLUSTERED 
(
	[sessionDurationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO
CREATE TABLE [ProgramSS] (
  [programID] int identity not null,
  [programPartnerID] int null,
  [facilitatorID] int null,
  [siteID] int null,
  [startDateID] int null,
  [startTimeID] int null,
  [sessionDurationID] int null,
  [sessionFrequencyID] int null,
  [programLengthID] int null,
  [programCapacity] int null,
  [programKit] int null,
  [registrationLinkID] varchar(255) null,
  [specialInstructionID] varchar(255) null
  CONSTRAINT [PK_programId] PRIMARY KEY CLUSTERED 
(
	[programId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE TABLE [dbo].[Facilitator] (
  [facilitatorID] [int] IDENTITY(1,1) NOT NULL,
  [firstName] varchar(255) NOT NULL,
  [lastName] varchar(255) NOT NULL,
  email varchar(255),
  mainPhone varchar(255),
  secondaryPhone varchar(255),
  trainingDate varchar(255),
  refresherDate varchar(255),
  [phoneNumber] varchar(250),
  CONSTRAINT [PK_facilitator] PRIMARY KEY CLUSTERED 
(
	[facilitatorId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [programPartner] (
  [programPartnerID] [int] IDENTITY(1,1) NOT NULL,
  [name] [varchar](255) NOT NULL,
  address varchar(255),
  contactName varchar(255),
  contactTitle varchar(255),
  mainPhone varchar(255),
  secondaryPhone varchar(255),
  email varchar(255),
  mainUrl varchar(255),
  note varchar(255),
  CONSTRAINT [PK_programPartner] PRIMARY KEY CLUSTERED 
(
	[programPartnerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO

CREATE TABLE [dbo].[Site] (
  [siteID] [int] IDENTITY(1,1) NOT NULL,
  [name] [varchar](255) NOT NULL,
  address varchar(255),
  contactName varchar(255),
  contactTitle varchar(255),
  mainPhone varchar(255),
  secondaryPhone varchar(255),
  registrationLink varchar(255),
  CONSTRAINT [PK_site] PRIMARY KEY CLUSTERED 
(
	[siteId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] 
GO
--INSERTS--
insert into programPartner(name) values
('Carizon Family & Community Services'),
('Country Hills Recreation Association'),
('EarlyON'), 
('Family & Children''s Services'), 
('House of Friendship'),
('Idea Exchange'),
('KidsAbility Centre for Child Development'),
('Kitchener Public Library'),
('Langs'),
('LINC English at First'),
('Project Read Literacy Network'),
('Region of Waterloo Healthy Baby Healthy Children'),
('Region of Waterloo Infant Child Development Program'),
('Region of Waterloo Public Library'),
('Wilmot Family Resource Centre'),
('YMCA of Cambridge & Kitchener-Waterloo'),
('YMCA Early Years Centre'),
('Other')

insert into startDate(name) values
('July 13'),
('July 20'),
('July 27'),
('August 3'),
('August 10'),
('August 17'),
('August 24'),
('August 31')

insert into sessionDuration(name) values
('20 minutes'),
('30 minutes'),
('40 minutes'),
('60 minutes'),
('Other')

insert into sessionFrequency(name) values
('Weekly'),
('Biweekly'),
('Other')

insert into programLength(name) values
('3 sessions'),
('4 sessions'),
('6 sessions'),
('8 sessions'),
('Other')

insert into startTime(name) values
('9:00am'), ('9:30am'),
('10:00am'),('10:30am'),
('11:00am'),('11:30am'),
('12:00pm'),('12:30pm'),
('1:00pm'), ('1:30pm'),
('2:00pm'),('2:30pm'),
('3:00pm'),('3:30pm'),
('4:00pm'),('4:30pm'),
('5:00pm'),('5:30pm'),
('6:00pm'),('6:30pm'),
('7:00pm'),('7:30pm'),
('8:00pm'),('8:30pm'),
('9:00pm'),('other')

insert into site(name) values
('Waterloo 1'),
('Waterloo 2'),
('Waterloo 3'),
('Cambridge 1')

insert into Facilitator(firstName, lastName) values
(('Jane'),('Doe')),
(('Jill'),('Evans')),
(('Josh'),('Stevens')),
(('Sharon'),('Karen'))
--ALTER TABLE--

GO
ALTER TABLE [dbo].[programSS]  WITH CHECK ADD  CONSTRAINT [FK_program_startTime] FOREIGN KEY([startTimeID])
REFERENCES [dbo].[startTime] ([startTimeID])
GO
ALTER TABLE [dbo].[programSS]  WITH CHECK ADD  CONSTRAINT [FK_program_programLength] FOREIGN KEY([programLengthID])
REFERENCES [dbo].[programLength] ([programLengthID])
GO
ALTER TABLE [dbo].[programSS]  WITH CHECK ADD  CONSTRAINT [FK_program_sessionFrequency] FOREIGN KEY([sessionFrequencyID])
REFERENCES [dbo].[sessionFrequency] ([sessionFrequencyID])
GO
ALTER TABLE [dbo].[programSS]  WITH CHECK ADD  CONSTRAINT [FK_program_sessionDuration] FOREIGN KEY([sessionDurationID])
REFERENCES [dbo].[sessionDuration] ([sessionDurationID])
GO
ALTER TABLE [dbo].[programSS]  WITH CHECK ADD  CONSTRAINT [FK_program_startDate] FOREIGN KEY([startDateID])
REFERENCES [dbo].[startDate] ([startDateID])
GO
ALTER TABLE [dbo].[programSS]  WITH CHECK ADD  CONSTRAINT [FK_program_site] FOREIGN KEY([siteID])
REFERENCES [dbo].[site] ([siteID])
GO
ALTER TABLE [dbo].[programSS]  WITH CHECK ADD  CONSTRAINT [FK_program_programPartner] FOREIGN KEY([programPartnerID])
REFERENCES [dbo].[programPartner] ([programPartnerID])
GO
ALTER TABLE [dbo].[programSS]  WITH CHECK ADD  CONSTRAINT [FK_program_facilitator] FOREIGN KEY([facilitatorID])
REFERENCES [dbo].[facilitator] ([facilitatorID])


--GO
--ALTER TABLE [dbo].[facilitator]  WITH CHECK ADD  CONSTRAINT [FK_facilitator_site] FOREIGN KEY([siteID])
--REFERENCES [dbo].[site] ([siteID])
--GO
--ALTER TABLE [dbo].[facilitator]  WITH CHECK ADD  CONSTRAINT [FK_facilitator_programPartner] FOREIGN KEY([programPartnerID])
--REFERENCES [dbo].[programPartner] ([programPartnerID])
--Go
--ALTER TABLE [dbo].[site]  WITH CHECK ADD  CONSTRAINT [FK_site_programPartner] FOREIGN KEY([programPartnerID])
--REFERENCES [dbo].[programPartner] ([programPartnerID])
--GO
