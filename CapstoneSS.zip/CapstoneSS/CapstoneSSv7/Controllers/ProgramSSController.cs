﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CapstoneSSv7.Models;

namespace CapstoneSSv7.Controllers
{
    public class ProgramSSController : Controller
    {
        private readonly StrongStartContext _context;

        public ProgramSSController(StrongStartContext context)
        {
            _context = context;
        }

        // GET: ProgramSS
        public async Task<IActionResult> Index()
        {
            var strongStartContext = _context.ProgramSs.Include(p => p.Facilitator).Include(p => p.ProgramLength).Include(p => p.ProgramPartner).Include(p => p.SessionDuration).Include(p => p.SessionFrequency).Include(p => p.Site).Include(p => p.StartDate).Include(p => p.StartTime);
            return View(await strongStartContext.ToListAsync());
        }

        // GET: ProgramSS/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programSs = await _context.ProgramSs
                .Include(p => p.Facilitator)
                .Include(p => p.ProgramLength)
                .Include(p => p.ProgramPartner)
                .Include(p => p.SessionDuration)
                .Include(p => p.SessionFrequency)
                .Include(p => p.Site)
                .Include(p => p.StartDate)
                .Include(p => p.StartTime)
                .FirstOrDefaultAsync(m => m.ProgramId == id);
            if (programSs == null)
            {
                return NotFound();
            }

            return View(programSs);
        }

        // GET: ProgramSS/Create
        public IActionResult Create()
        {
            ViewData["FacilitatorId"] = new SelectList(_context.Facilitator, "FacilitatorId", "FirstName");
            ViewData["ProgramLengthId"] = new SelectList(_context.ProgramLength, "ProgramLengthId", "Name");
            ViewData["ProgramPartnerId"] = new SelectList(_context.ProgramPartner, "ProgramPartnerId", "Name");
            ViewData["SessionDurationId"] = new SelectList(_context.SessionDuration, "SessionDurationId", "Name");
            ViewData["SessionFrequencyId"] = new SelectList(_context.SessionFrequency, "SessionFrequencyId", "Name");
            ViewData["SiteId"] = new SelectList(_context.Site, "SiteId", "Name");
            ViewData["StartDateId"] = new SelectList(_context.StartDate, "StartDateId", "Name");
            ViewData["StartTimeId"] = new SelectList(_context.StartTime, "StartTimeId", "Name");
            return View();
        }

        // POST: ProgramSS/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProgramId,ProgramPartnerId,FacilitatorId,SiteId,StartDateId,StartTimeId,SessionDurationId,SessionFrequencyId,ProgramLengthId,ProgramCapacity,ProgramKit,RegistrationLinkId,SpecialInstructionId")] ProgramSs programSs)
        {
            if (ModelState.IsValid)
            {
                _context.Add(programSs);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["FacilitatorId"] = new SelectList(_context.Facilitator, "FacilitatorId", "FirstName", programSs.FacilitatorId);
            ViewData["ProgramLengthId"] = new SelectList(_context.ProgramLength, "ProgramLengthId", "Name", programSs.ProgramLengthId);
            ViewData["ProgramPartnerId"] = new SelectList(_context.ProgramPartner, "ProgramPartnerId", "Name", programSs.ProgramPartnerId);
            ViewData["SessionDurationId"] = new SelectList(_context.SessionDuration, "SessionDurationId", "Name", programSs.SessionDurationId);
            ViewData["SessionFrequencyId"] = new SelectList(_context.SessionFrequency, "SessionFrequencyId", "Name", programSs.SessionFrequencyId);
            ViewData["SiteId"] = new SelectList(_context.Site, "SiteId", "Name", programSs.SiteId);
            ViewData["StartDateId"] = new SelectList(_context.StartDate, "StartDateId", "Name", programSs.StartDateId);
            ViewData["StartTimeId"] = new SelectList(_context.StartTime, "StartTimeId", "Name", programSs.StartTimeId);
            return View(programSs);
        }

        // GET: ProgramSS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programSs = await _context.ProgramSs.FindAsync(id);
            if (programSs == null)
            {
                return NotFound();
            }
            ViewData["FacilitatorId"] = new SelectList(_context.Facilitator, "FacilitatorId", "FirstName", programSs.FacilitatorId);
            ViewData["ProgramLengthId"] = new SelectList(_context.ProgramLength, "ProgramLengthId", "Name", programSs.ProgramLengthId);
            ViewData["ProgramPartnerId"] = new SelectList(_context.ProgramPartner, "ProgramPartnerId", "Name", programSs.ProgramPartnerId);
            ViewData["SessionDurationId"] = new SelectList(_context.SessionDuration, "SessionDurationId", "Name", programSs.SessionDurationId);
            ViewData["SessionFrequencyId"] = new SelectList(_context.SessionFrequency, "SessionFrequencyId", "Name", programSs.SessionFrequencyId);
            ViewData["SiteId"] = new SelectList(_context.Site, "SiteId", "Name", programSs.SiteId);
            ViewData["StartDateId"] = new SelectList(_context.StartDate, "StartDateId", "Name", programSs.StartDateId);
            ViewData["StartTimeId"] = new SelectList(_context.StartTime, "StartTimeId", "Name", programSs.StartTimeId);
            return View(programSs);
        }

        // POST: ProgramSS/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProgramId,ProgramPartnerId,FacilitatorId,SiteId,StartDateId,StartTimeId,SessionDurationId,SessionFrequencyId,ProgramLengthId,ProgramCapacity,ProgramKit,RegistrationLinkId,SpecialInstructionId")] ProgramSs programSs)
        {
            if (id != programSs.ProgramId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(programSs);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProgramSsExists(programSs.ProgramId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["FacilitatorId"] = new SelectList(_context.Facilitator, "FacilitatorId", "FirstName", programSs.FacilitatorId);
            ViewData["ProgramLengthId"] = new SelectList(_context.ProgramLength, "ProgramLengthId", "Name", programSs.ProgramLengthId);
            ViewData["ProgramPartnerId"] = new SelectList(_context.ProgramPartner, "ProgramPartnerId", "Name", programSs.ProgramPartnerId);
            ViewData["SessionDurationId"] = new SelectList(_context.SessionDuration, "SessionDurationId", "Name", programSs.SessionDurationId);
            ViewData["SessionFrequencyId"] = new SelectList(_context.SessionFrequency, "SessionFrequencyId", "Name", programSs.SessionFrequencyId);
            ViewData["SiteId"] = new SelectList(_context.Site, "SiteId", "Name", programSs.SiteId);
            ViewData["StartDateId"] = new SelectList(_context.StartDate, "StartDateId", "Name", programSs.StartDateId);
            ViewData["StartTimeId"] = new SelectList(_context.StartTime, "StartTimeId", "Name", programSs.StartTimeId);
            return View(programSs);
        }

        // GET: ProgramSS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programSs = await _context.ProgramSs
                .Include(p => p.Facilitator)
                .Include(p => p.ProgramLength)
                .Include(p => p.ProgramPartner)
                .Include(p => p.SessionDuration)
                .Include(p => p.SessionFrequency)
                .Include(p => p.Site)
                .Include(p => p.StartDate)
                .Include(p => p.StartTime)
                .FirstOrDefaultAsync(m => m.ProgramId == id);
            if (programSs == null)
            {
                return NotFound();
            }

            return View(programSs);
        }

        // POST: ProgramSS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var programSs = await _context.ProgramSs.FindAsync(id);
            _context.ProgramSs.Remove(programSs);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProgramSsExists(int id)
        {
            return _context.ProgramSs.Any(e => e.ProgramId == id);
        }
    }
}
