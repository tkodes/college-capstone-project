﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CapstoneSSv7.Models;
using Microsoft.AspNetCore.Http;

namespace CapstoneSSv7.Controllers
{
    public class ProgramSSController : Controller
    {
        private readonly StrongStartContext _context;

        public ProgramSSController(StrongStartContext context)
        {
            _context = context;
        }

        // GET: ProgramSS
        public async Task<IActionResult> Index(string SiteId, string FacilitatorId, string ProgramPartnerId)
        {

            if (!string.IsNullOrEmpty(SiteId))
            {
                // store in Cookies or sessions
                Response.Cookies.Append("SiteId", SiteId);
                HttpContext.Session.SetString("SiteId", SiteId);

                var site = _context.Site.Where(s => s.SiteId == Convert.ToInt32(SiteId)).FirstOrDefault();
                ViewData["site"] = site.Name;

                var strongStartContext = _context.ProgramSs.Include(p => p.Facilitator).Include(p => p.ProgramLength).Include(p => p.ProgramPartner).Include(p => p.SessionDuration).Include(p => p.SessionFrequency).Include(p => p.Site).Include(p => p.StartDate).Include(p => p.StartTime)
                .Where(s => s.SiteId == Convert.ToInt32(SiteId));

                TempData["message"] = ViewData["site"];

                return View(await strongStartContext.ToListAsync());

            }
            else if (Request.Query["SiteId"].Any())
            {
                //store in cookides or session
                Response.Cookies.Append("SiteId", Request.Query["SiteId"].ToString());
                HttpContext.Session.SetString("SiteId", Request.Query["SiteId"].ToString());
                SiteId = Request.Query["SiteId"].ToString();
            }
            if (!string.IsNullOrEmpty(FacilitatorId))
            {
                // store in Cookies or sessions
                Response.Cookies.Append("FacilitatorId", FacilitatorId);
                HttpContext.Session.SetString("FacilitatorId", FacilitatorId);

                var strongStartContext = _context.ProgramSs.Include(p => p.Facilitator).Include(p => p.ProgramLength).Include(p => p.ProgramPartner).Include(p => p.SessionDuration).Include(p => p.SessionFrequency).Include(p => p.Site).Include(p => p.StartDate).Include(p => p.StartTime)
                .Where(s => s.FacilitatorId == Convert.ToInt32(FacilitatorId));

                var facilitator = _context.Facilitator.Where(s => s.FacilitatorId == Convert.ToInt32(FacilitatorId)).FirstOrDefault();
                ViewData["facilitator"] = facilitator.FirstName + " " + facilitator.LastName;

                TempData["message"] = ViewData["facilitator"];

                return View(await strongStartContext.ToListAsync());

            }
            else if (Request.Query["FacilitatorId"].Any())
            {
                //store in cookides or session
                Response.Cookies.Append("FacilitatorId", Request.Query["FacilitatorId"].ToString());
                HttpContext.Session.SetString("FacilitatorId", Request.Query["FacilitatorId"].ToString());
                FacilitatorId = Request.Query["FacilitatorId"].ToString();
            }
            if (!string.IsNullOrEmpty(ProgramPartnerId))
            {
                // store in Cookies or sessions
                Response.Cookies.Append("ProgramPartnerId", ProgramPartnerId);
                HttpContext.Session.SetString("ProgramPartnerId", ProgramPartnerId);

                var strongStartContext = _context.ProgramSs.Include(p => p.Facilitator).Include(p => p.ProgramLength).Include(p => p.ProgramPartner).Include(p => p.SessionDuration).Include(p => p.SessionFrequency).Include(p => p.Site).Include(p => p.StartDate).Include(p => p.StartTime)
                .Where(s => s.ProgramPartnerId == Convert.ToInt32(ProgramPartnerId));

                var programPartner = _context.ProgramPartner.Where(s => s.ProgramPartnerId == Convert.ToInt32(ProgramPartnerId)).FirstOrDefault();
                ViewData["programPartner"] = programPartner.Name;

                TempData["message"] = ViewData["programPartner"];

                return View(await strongStartContext.ToListAsync());

            }
            else if (Request.Query["ProgramPartnerId"].Any())
            {
                //store in cookides or session
                Response.Cookies.Append("ProgramPartnerId", Request.Query["ProgramPartnerId"].ToString());
                HttpContext.Session.SetString("ProgramPartnerId", Request.Query["ProgramPartnerId"].ToString());
                ProgramPartnerId = Request.Query["ProgramPartnerId"].ToString();
            }




            //else if (Request.Cookies["SiteId"] != null)

            //{
            //    SiteId = Request.Cookies["SiteId"].ToString();
            //}
            //else if (HttpContext.Session.GetString("SiteId") != null)
            //{
            //    SiteId = HttpContext.Session.GetString("SiteId");
            //}
            //else
            //{
            //    TempData["message"] = "Please Select any site";
            //    return RedirectToAction("Index", "Site");
            //}

            var strongStartContextMain = _context.ProgramSs.Include(p => p.Facilitator).Include(p => p.ProgramLength).Include(p => p.ProgramPartner).Include(p => p.SessionDuration).Include(p => p.SessionFrequency).Include(p => p.Site).Include(p => p.StartDate).Include(p => p.StartTime);

            return View(await strongStartContextMain.ToListAsync());

        }

        // GET: ProgramSS/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programSs = await _context.ProgramSs
                .Include(p => p.Facilitator)
                .Include(p => p.ProgramLength)
                .Include(p => p.ProgramPartner)
                .Include(p => p.SessionDuration)
                .Include(p => p.SessionFrequency)
                .Include(p => p.Site)
                .Include(p => p.StartDate)
                .Include(p => p.StartTime)
                .FirstOrDefaultAsync(m => m.ProgramId == id);
            if (programSs == null)
            {
                return NotFound();
            }

            return View(programSs);
        }

        // GET: ProgramSS/Create
        public IActionResult Create()
        {
            ViewData["FacilitatorId"] = new SelectList(_context.Facilitator, "FacilitatorId", "FirstName");
            ViewData["ProgramLengthId"] = new SelectList(_context.ProgramLength, "ProgramLengthId", "Name");
            ViewData["ProgramPartnerId"] = new SelectList(_context.ProgramPartner, "ProgramPartnerId", "Name");
            ViewData["SessionDurationId"] = new SelectList(_context.SessionDuration, "SessionDurationId", "Name");
            ViewData["SessionFrequencyId"] = new SelectList(_context.SessionFrequency, "SessionFrequencyId", "Name");
            ViewData["SiteId"] = new SelectList(_context.Site, "SiteId", "Name");
            ViewData["StartDateId"] = new SelectList(_context.StartDate, "StartDateId", "Name");
            ViewData["StartTimeId"] = new SelectList(_context.StartTime, "StartTimeId", "Name");
            return View();
        }

        // POST: ProgramSS/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProgramId,ProgramPartnerId,FacilitatorId,SiteId,StartDateId,StartTimeId,SessionDurationId,SessionFrequencyId,ProgramLengthId,ProgramCapacity,ProgramKit,RegistrationLinkId,SpecialInstructionId")] ProgramSs programSs)
        {
            if (ModelState.IsValid)
            {
                _context.Add(programSs);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["FacilitatorId"] = new SelectList(_context.Facilitator, "FacilitatorId", "FirstName", programSs.FacilitatorId);
            ViewData["ProgramLengthId"] = new SelectList(_context.ProgramLength, "ProgramLengthId", "Name", programSs.ProgramLengthId);
            ViewData["ProgramPartnerId"] = new SelectList(_context.ProgramPartner, "ProgramPartnerId", "Name", programSs.ProgramPartnerId);
            ViewData["SessionDurationId"] = new SelectList(_context.SessionDuration, "SessionDurationId", "Name", programSs.SessionDurationId);
            ViewData["SessionFrequencyId"] = new SelectList(_context.SessionFrequency, "SessionFrequencyId", "Name", programSs.SessionFrequencyId);
            ViewData["SiteId"] = new SelectList(_context.Site, "SiteId", "Name", programSs.SiteId);
            ViewData["StartDateId"] = new SelectList(_context.StartDate, "StartDateId", "Name", programSs.StartDateId);
            ViewData["StartTimeId"] = new SelectList(_context.StartTime, "StartTimeId", "Name", programSs.StartTimeId);
            return View(programSs);
        }

        // GET: ProgramSS/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programSs = await _context.ProgramSs.FindAsync(id);
            if (programSs == null)
            {
                return NotFound();
            }
            ViewData["FacilitatorId"] = new SelectList(_context.Facilitator, "FacilitatorId", "FirstName", programSs.FacilitatorId);
            ViewData["ProgramLengthId"] = new SelectList(_context.ProgramLength, "ProgramLengthId", "Name", programSs.ProgramLengthId);
            ViewData["ProgramPartnerId"] = new SelectList(_context.ProgramPartner, "ProgramPartnerId", "Name", programSs.ProgramPartnerId);
            ViewData["SessionDurationId"] = new SelectList(_context.SessionDuration, "SessionDurationId", "Name", programSs.SessionDurationId);
            ViewData["SessionFrequencyId"] = new SelectList(_context.SessionFrequency, "SessionFrequencyId", "Name", programSs.SessionFrequencyId);
            ViewData["SiteId"] = new SelectList(_context.Site, "SiteId", "Name", programSs.SiteId);
            ViewData["StartDateId"] = new SelectList(_context.StartDate, "StartDateId", "Name", programSs.StartDateId);
            ViewData["StartTimeId"] = new SelectList(_context.StartTime, "StartTimeId", "Name", programSs.StartTimeId);
            return View(programSs);
        }

        // POST: ProgramSS/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProgramId,ProgramPartnerId,FacilitatorId,SiteId,StartDateId,StartTimeId,SessionDurationId,SessionFrequencyId,ProgramLengthId,ProgramCapacity,ProgramKit,RegistrationLinkId,SpecialInstructionId")] ProgramSs programSs)
        {
            if (id != programSs.ProgramId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(programSs);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProgramSsExists(programSs.ProgramId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["FacilitatorId"] = new SelectList(_context.Facilitator, "FacilitatorId", "FirstName", programSs.FacilitatorId);
            ViewData["ProgramLengthId"] = new SelectList(_context.ProgramLength, "ProgramLengthId", "Name", programSs.ProgramLengthId);
            ViewData["ProgramPartnerId"] = new SelectList(_context.ProgramPartner, "ProgramPartnerId", "Name", programSs.ProgramPartnerId);
            ViewData["SessionDurationId"] = new SelectList(_context.SessionDuration, "SessionDurationId", "Name", programSs.SessionDurationId);
            ViewData["SessionFrequencyId"] = new SelectList(_context.SessionFrequency, "SessionFrequencyId", "Name", programSs.SessionFrequencyId);
            ViewData["SiteId"] = new SelectList(_context.Site, "SiteId", "Name", programSs.SiteId);
            ViewData["StartDateId"] = new SelectList(_context.StartDate, "StartDateId", "Name", programSs.StartDateId);
            ViewData["StartTimeId"] = new SelectList(_context.StartTime, "StartTimeId", "Name", programSs.StartTimeId);
            return View(programSs);
        }

        // GET: ProgramSS/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programSs = await _context.ProgramSs
                .Include(p => p.Facilitator)
                .Include(p => p.ProgramLength)
                .Include(p => p.ProgramPartner)
                .Include(p => p.SessionDuration)
                .Include(p => p.SessionFrequency)
                .Include(p => p.Site)
                .Include(p => p.StartDate)
                .Include(p => p.StartTime)
                .FirstOrDefaultAsync(m => m.ProgramId == id);
            if (programSs == null)
            {
                return NotFound();
            }

            return View(programSs);
        }

        // POST: ProgramSS/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var programSs = await _context.ProgramSs.FindAsync(id);
            _context.ProgramSs.Remove(programSs);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProgramSsExists(int id)
        {
            return _context.ProgramSs.Any(e => e.ProgramId == id);
        }
    }
}
