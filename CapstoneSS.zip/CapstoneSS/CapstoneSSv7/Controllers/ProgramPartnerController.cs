﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CapstoneSSv7.Models;

namespace CapstoneSSv7.Controllers
{
    public class ProgramPartnerController : Controller
    {
        private readonly StrongStartContext _context;

        public ProgramPartnerController(StrongStartContext context)
        {
            _context = context;
        }

        // GET: ProgramPartner
        public async Task<IActionResult> Index()
        {
            return View(await _context.ProgramPartner.ToListAsync());
        }

        // GET: ProgramPartner/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programPartner = await _context.ProgramPartner
                .FirstOrDefaultAsync(m => m.ProgramPartnerId == id);
            if (programPartner == null)
            {
                return NotFound();
            }

            return View(programPartner);
        }

        // GET: ProgramPartner/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ProgramPartner/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProgramPartnerId,Name,Address,ContactName,ContactTitle,MainPhone,SecondaryPhone,Email,MainUrl,Note")] ProgramPartner programPartner)
        {
            if (ModelState.IsValid)
            {
                _context.Add(programPartner);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(programPartner);
        }

        // GET: ProgramPartner/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programPartner = await _context.ProgramPartner.FindAsync(id);
            if (programPartner == null)
            {
                return NotFound();
            }
            return View(programPartner);
        }

        // POST: ProgramPartner/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProgramPartnerId,Name,Address,ContactName,ContactTitle,MainPhone,SecondaryPhone,Email,MainUrl,Note")] ProgramPartner programPartner)
        {
            if (id != programPartner.ProgramPartnerId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(programPartner);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProgramPartnerExists(programPartner.ProgramPartnerId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(programPartner);
        }

        // GET: ProgramPartner/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var programPartner = await _context.ProgramPartner
                .FirstOrDefaultAsync(m => m.ProgramPartnerId == id);
            if (programPartner == null)
            {
                return NotFound();
            }

            return View(programPartner);
        }

        // POST: ProgramPartner/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var programPartner = await _context.ProgramPartner.FindAsync(id);
            _context.ProgramPartner.Remove(programPartner);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProgramPartnerExists(int id)
        {
            return _context.ProgramPartner.Any(e => e.ProgramPartnerId == id);
        }
    }
}
