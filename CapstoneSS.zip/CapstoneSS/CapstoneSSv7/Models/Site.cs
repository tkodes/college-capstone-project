﻿using System;
using System.Collections.Generic;

namespace CapstoneSSv7.Models
{
    public partial class Site
    {
        public Site()
        {
            ProgramSs = new HashSet<ProgramSs>();
        }

        public int SiteId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string ContactName { get; set; }
        public string ContactTitle { get; set; }
        public string MainPhone { get; set; }
        public string SecondaryPhone { get; set; }
        public string RegistrationLink { get; set; }

        public virtual ICollection<ProgramSs> ProgramSs { get; set; }
    }
}
