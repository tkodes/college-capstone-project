﻿using System;
using System.Collections.Generic;

namespace CapstoneSSv7.Models
{
    public partial class ProgramSs
    {
        public int ProgramId { get; set; }
        public int? ProgramPartnerId { get; set; }
        public int? FacilitatorId { get; set; }
        public int? SiteId { get; set; }
        public int? StartDateId { get; set; }
        public int? StartTimeId { get; set; }
        public int? SessionDurationId { get; set; }
        public int? SessionFrequencyId { get; set; }
        public int? ProgramLengthId { get; set; }
        public int? ProgramCapacity { get; set; }
        public int? ProgramKit { get; set; }
        public string RegistrationLinkId { get; set; }
        public string SpecialInstructionId { get; set; }

        public virtual Facilitator Facilitator { get; set; }
        public virtual ProgramLength ProgramLength { get; set; }
        public virtual ProgramPartner ProgramPartner { get; set; }
        public virtual SessionDuration SessionDuration { get; set; }
        public virtual SessionFrequency SessionFrequency { get; set; }
        public virtual Site Site { get; set; }
        public virtual StartDate StartDate { get; set; }
        public virtual StartTime StartTime { get; set; }
    }
}
