﻿using System;
using System.Collections.Generic;

namespace CapstoneSSv7.Models
{
    public partial class RegistrationLink
    {
        public RegistrationLink()
        {
            ProgramSs = new HashSet<ProgramSs>();
        }

        public string RegistrationLinkId { get; set; }

        public virtual ICollection<ProgramSs> ProgramSs { get; set; }
    }
}
