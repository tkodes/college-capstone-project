﻿using System;
using System.Collections.Generic;

namespace CapstoneSSv7.Models
{
    public partial class ProgramLength
    {
        public ProgramLength()
        {
            ProgramSs = new HashSet<ProgramSs>();
        }

        public int ProgramLengthId { get; set; }
        public string Name { get; set; }

        public virtual ICollection<ProgramSs> ProgramSs { get; set; }
    }
}
