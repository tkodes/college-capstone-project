﻿using System;
using System.Collections.Generic;

namespace CapstoneSSv7.Models
{
    public partial class SpecialInstruction
    {
        public SpecialInstruction()
        {
            ProgramSs = new HashSet<ProgramSs>();
        }

        public string SpecialInstructionId { get; set; }

        public virtual ICollection<ProgramSs> ProgramSs { get; set; }
    }
}
