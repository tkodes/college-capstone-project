﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CapstoneSSv7.Models
{
    public partial class StrongStartContext : DbContext
    {
        public StrongStartContext()
        {
        }

        public StrongStartContext(DbContextOptions<StrongStartContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Facilitator> Facilitator { get; set; }
        public virtual DbSet<ProgramLength> ProgramLength { get; set; }
        public virtual DbSet<ProgramPartner> ProgramPartner { get; set; }
        public virtual DbSet<ProgramSs> ProgramSs { get; set; }
        public virtual DbSet<SessionDuration> SessionDuration { get; set; }
        public virtual DbSet<SessionFrequency> SessionFrequency { get; set; }
        public virtual DbSet<Site> Site { get; set; }
        public virtual DbSet<StartDate> StartDate { get; set; }
        public virtual DbSet<StartTime> StartTime { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=.\\sqlexpress;Database=StrongStart;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Facilitator>(entity =>
            {
                entity.Property(e => e.FacilitatorId).HasColumnName("facilitatorID");

                entity.Property(e => e.Email)
                    .HasColumnName("email")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnName("firstName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasColumnName("lastName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MainPhone)
                    .HasColumnName("mainPhone")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNumber)
                    .HasColumnName("phoneNumber")
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.RefresherDate)
                    .HasColumnName("refresherDate")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SecondaryPhone)
                    .HasColumnName("secondaryPhone")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.TrainingDate)
                    .HasColumnName("trainingDate")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProgramLength>(entity =>
            {
                entity.ToTable("programLength");

                entity.Property(e => e.ProgramLengthId).HasColumnName("programLengthID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProgramPartner>(entity =>
            {
                entity.ToTable("programPartner");

                entity.Property(e => e.ProgramPartnerId).HasColumnName("programPartnerID");

                entity.Property(e => e.Address)
                    .HasColumnName("address")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ContactName)
                    .HasColumnName("contactName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ContactTitle)
                    .HasColumnName("contactTitle")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .HasColumnName("email")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MainPhone)
                    .HasColumnName("mainPhone")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MainUrl)
                    .HasColumnName("mainUrl")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Note)
                    .HasColumnName("note")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SecondaryPhone)
                    .HasColumnName("secondaryPhone")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProgramSs>(entity =>
            {
                entity.HasKey(e => e.ProgramId)
                    .HasName("PK_programId");

                entity.ToTable("ProgramSS");

                entity.Property(e => e.ProgramId).HasColumnName("programID");

                entity.Property(e => e.FacilitatorId).HasColumnName("facilitatorID");

                entity.Property(e => e.ProgramCapacity).HasColumnName("programCapacity");

                entity.Property(e => e.ProgramKit).HasColumnName("programKit");

                entity.Property(e => e.ProgramLengthId).HasColumnName("programLengthID");

                entity.Property(e => e.ProgramPartnerId).HasColumnName("programPartnerID");

                entity.Property(e => e.RegistrationLinkId)
                    .HasColumnName("registrationLinkID")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SessionDurationId).HasColumnName("sessionDurationID");

                entity.Property(e => e.SessionFrequencyId).HasColumnName("sessionFrequencyID");

                entity.Property(e => e.SiteId).HasColumnName("siteID");

                entity.Property(e => e.SpecialInstructionId)
                    .HasColumnName("specialInstructionID")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.StartDateId).HasColumnName("startDateID");

                entity.Property(e => e.StartTimeId).HasColumnName("startTimeID");

                entity.HasOne(d => d.Facilitator)
                    .WithMany(p => p.ProgramSs)
                    .HasForeignKey(d => d.FacilitatorId)
                    .HasConstraintName("FK_program_facilitator");

                entity.HasOne(d => d.ProgramLength)
                    .WithMany(p => p.ProgramSs)
                    .HasForeignKey(d => d.ProgramLengthId)
                    .HasConstraintName("FK_program_programLength");

                entity.HasOne(d => d.ProgramPartner)
                    .WithMany(p => p.ProgramSs)
                    .HasForeignKey(d => d.ProgramPartnerId)
                    .HasConstraintName("FK_program_programPartner");

                entity.HasOne(d => d.SessionDuration)
                    .WithMany(p => p.ProgramSs)
                    .HasForeignKey(d => d.SessionDurationId)
                    .HasConstraintName("FK_program_sessionDuration");

                entity.HasOne(d => d.SessionFrequency)
                    .WithMany(p => p.ProgramSs)
                    .HasForeignKey(d => d.SessionFrequencyId)
                    .HasConstraintName("FK_program_sessionFrequency");

                entity.HasOne(d => d.Site)
                    .WithMany(p => p.ProgramSs)
                    .HasForeignKey(d => d.SiteId)
                    .HasConstraintName("FK_program_site");

                entity.HasOne(d => d.StartDate)
                    .WithMany(p => p.ProgramSs)
                    .HasForeignKey(d => d.StartDateId)
                    .HasConstraintName("FK_program_startDate");

                entity.HasOne(d => d.StartTime)
                    .WithMany(p => p.ProgramSs)
                    .HasForeignKey(d => d.StartTimeId)
                    .HasConstraintName("FK_program_startTime");
            });

            modelBuilder.Entity<SessionDuration>(entity =>
            {
                entity.Property(e => e.SessionDurationId).HasColumnName("sessionDurationID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SessionFrequency>(entity =>
            {
                entity.ToTable("sessionFrequency");

                entity.Property(e => e.SessionFrequencyId).HasColumnName("sessionFrequencyID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Site>(entity =>
            {
                entity.Property(e => e.SiteId).HasColumnName("siteID");

                entity.Property(e => e.Address)
                    .HasColumnName("address")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ContactName)
                    .HasColumnName("contactName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ContactTitle)
                    .HasColumnName("contactTitle")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MainPhone)
                    .HasColumnName("mainPhone")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.RegistrationLink)
                    .HasColumnName("registrationLink")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SecondaryPhone)
                    .HasColumnName("secondaryPhone")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StartDate>(entity =>
            {
                entity.ToTable("startDate");

                entity.Property(e => e.StartDateId).HasColumnName("startDateID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<StartTime>(entity =>
            {
                entity.Property(e => e.StartTimeId).HasColumnName("startTimeID");

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasColumnName("name")
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
