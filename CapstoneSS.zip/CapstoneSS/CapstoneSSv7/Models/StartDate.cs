﻿using System;
using System.Collections.Generic;

namespace CapstoneSSv7.Models
{
    public partial class StartDate
    {
        public StartDate()
        {
            ProgramSs = new HashSet<ProgramSs>();
        }

        public int StartDateId { get; set; }
        public string Name { get; set; }

        public virtual ICollection<ProgramSs> ProgramSs { get; set; }
    }
}
