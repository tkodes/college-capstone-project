﻿using System;
using System.Collections.Generic;

namespace CapstoneSSv7.Models
{
    public partial class Facilitator
    {
        public Facilitator()
        {
            ProgramSs = new HashSet<ProgramSs>();
        }

        public int FacilitatorId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string MainPhone { get; set; }
        public string SecondaryPhone { get; set; }
        public string TrainingDate { get; set; }
        public string RefresherDate { get; set; }
        public string PhoneNumber { get; set; }

        public virtual ICollection<ProgramSs> ProgramSs { get; set; }
    }
}
